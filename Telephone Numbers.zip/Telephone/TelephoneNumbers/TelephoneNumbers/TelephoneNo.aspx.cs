﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace TelephoneNumbers
{
    public partial class Telno : System.Web.UI.Page
    {
        int[] no = new int[12];
        SqlConnection baglanti;
      
        protected void bttnEnter_Click(object sender, EventArgs e)
        {
            string telno;
            telno = TextBox.Text;



            char[] characters = telno.ToCharArray();

            int[] x = { 9, 0, 8, 5, 0, 8, 8, 5 };

            for (int i = 0; i < no.Length; i++)
                no[i] = Convert.ToInt32(characters[i].ToString());


            for (int i = 0; i < 8; i++)
            {
                if (no[i] != x[i])
                    lblOutput.Text = "Geçersiz numara...";
                else if (no[i] == x[i])
                {
                    baglanti = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\öznur\Documents\Telephone\TelephoneNumbers\TelephoneNumbers\App_Data\telephone.mdf;Integrated Security=True");
                    baglanti.Open();

                    OzelnoKontrol();
                }
                baglanti.Close();  

            }
            
        }

        public void OzelnoKontrol()
        {
            int i = 8;
            bool flag = false;

            for (int j = 0; j < 4; j++)
            {
                for (int k = 0; k <= 9; k++)
                {
                    if (no[i] == j && no[i + 1] == j && no[i + 2] == j && no[i + 3] == j && k <= 3)
                    {
                        lblOutput.Text = "ÖZEL NUMARA - FİYAT = 1180 TL";
                        flag = true;
                    } 

                    else if (no[i] == j && no[i + 1] == 8 && no[i + 2] == 8 && no[i + 3] == 5)
                    {
                        lblOutput.Text = "ÖZEL NUMARA - FİYAT = 1180 TL";  
                        flag = true;
                    }

                    else if (no[i] == j && no[i + 1] == k && no[i + 2] == k && no[i + 3] == k)
                    {
                        if ((j == 1 && k != 1) || (j == 2 && k != 2) || (j == 3 && k != 3))
                            lblOutput.Text = "ÖZEL NUMARA - FİYAT = 590 TL"; 
                        flag = true;
                    }

                    else if (no[i] == j && no[i + 1] == k && no[i + 2] == j && no[i + 3] == k)
                    {
                        lblOutput.Text = "ÖZEL NUMARA - FİYAT = 590 TL";  
                        flag = true;
                    }

                    else if (no[i] == j && no[i + 1] == j && no[i + 2] == k && no[i + 3] == k)
                    {
                        lblOutput.Text = "ÖZEL NUMARA - FİYAT = 295 TL";
                        flag = true;
                    }  

                    else if (no[i] == j && no[i + 1] == 0 && no[i + 2] == k && no[i + 3] == 0)    
                    {
                        if ((j == 1 && k == 1) || (j == 2 && k == 2) || (j == 3 && k == 3))
                            lblOutput.Text = "ÖZEL NUMARA - FİYAT = 590 TL";
                        else
                            lblOutput.Text = "ÖZEL NUMARA - FİYAT = 118 TL";
                        flag = true;
                    }                                                                                 
                    else if (no[i] == j && no[i + 1] == j + 1 && no[i + 2] == j + 2 && no[i + 3] == j + 3)
                    { // ardışık sayılar bir bir artan  // 0123 - 1234 - 2345 - 3456
                        lblOutput.Text = "ÖZEL NUMARA - FİYAT = 118 TL";
                        flag = true;
                    }

                    else if (no[i] == 3 && no[i + 1] == 2 && no[i + 2] == 1 && no[i + 3] == 0)
                    {    // bir bir azalarak ardışık olan geçerli aralıktaki numara 3210
                        lblOutput.Text = "ÖZEL NUMARA - FİYAT = 118 TL";
                        flag = true;
                    }
                    // ardışık sayılar çift 0246 - 2468
                    else if ((j == 0 || j == 1) && no[i] == 2 * j && no[i + 1] == 2 * (j + 1) && no[i + 2] == 2 * (j + 2) && no[i + 3] == 2 * (j + 3))
                    {
                        lblOutput.Text = "ÖZEL NUMARA - FİYAT = 118 TL";
                        flag = true;
                    }
                    // ardışık sayılar tek sayılar 1357 - 3579
                    else if ((j == 0 || j == 1) && no[i] == 2 * j + 1 && no[i + 1] == 2 * (j + 1) + 1 && no[i + 2] == 2 * (j + 2) + 1 && no[i + 3] == 2 * (j + 3) + 1)
                    {
                        lblOutput.Text = "ÖZEL NUMARA - FİYAT = 118 TL";
                        flag = true;
                    }
                    // üçün katı olan ardışık sayı 0369(sadece) geçerli olan
                    else if (j == 0 && no[i] == 3 * j && no[i + 1] == 3 * (j + 1) && no[i + 2] == 3 * (j + 2) && no[i + 3] == 3 * (j + 3))
                    {
                        lblOutput.Text = "ÖZEL NUMARA - FİYAT = 118 TL";
                        flag = true;
                    }

                    else if (no[i] >= 4)
                    {
                        lblOutput.Text = "GEÇERSİZ NUMARA";
                        flag = true;
                    }

                   
                    // Diğer jenerik anlam taşıyan numaralar için veritabanı kullanılabilir böylelikle daha sonradan jenerik numaralar eklenebilir.            
                    SqlCommand komut = new SqlCommand("SELECT JENERIC FROM JENERICNUMBER WHERE JENERIC='" + TextBox.Text + "'", baglanti);
                    SqlDataReader oku = komut.ExecuteReader();
                    while (oku.Read())
                    {
                        lblOutput.Text = "ÖZEL NUMARA - FİYAT = 59 TL";
                        flag = true;
                    }
                    oku.Close();

                    if (flag==false)
                    {
                        lblOutput.Text = "NORMAL NUMARA";
                    }

                }
            }
        }       
    }
}